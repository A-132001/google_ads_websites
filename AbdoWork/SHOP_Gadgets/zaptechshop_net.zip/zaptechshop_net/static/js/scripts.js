/**
 * VShopGizmo - Main JavaScript
 * Contains functionality for navigation, search, product filtering, and cookie consent
 */

document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');

    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', function() {
            if (mobileMenu.classList.contains('hidden')) {
                mobileMenu.classList.remove('hidden');
            } else {
                mobileMenu.classList.add('hidden');
            }
        });
    }

    // Search functionality
    const searchBars = document.querySelectorAll('#searchbar, #mobile-searchbar');
    
    searchBars.forEach(searchBar => {
        if (searchBar) {
            searchBar.addEventListener('keyup', function(event) {
                // Execute search on Enter key press
                if (event.key === 'Enter') {
                    performSearch(searchBar.value);
                }
            });
        }
    });

    function performSearch(query) {
        // Normalize the search query
        query = query.toLowerCase().trim();
        
        if (query === '') return;
        
        console.log(`Searching for: ${query}`);
        
        // Get all searchable elements (product cards, review articles, etc.)
        const searchableElements = document.querySelectorAll('article, .product-card');
        let hasResults = false;
        
        searchableElements.forEach(element => {
            const text = element.textContent.toLowerCase();
            
            if (text.includes(query)) {
                element.style.display = '';
                hasResults = true;
            } else {
                element.style.display = 'none';
            }
        });
        
        // Show/hide the "no results" message if present
        const noResultsMessage = document.getElementById('no-results');
        if (noResultsMessage) {
            if (hasResults) {
                noResultsMessage.classList.add('hidden');
            } else {
                noResultsMessage.classList.remove('hidden');
            }
        }
    }

    // Category filter functionality on products page
    const categoryButtons = document.querySelectorAll('.category-btn');
    const productCards = document.querySelectorAll('.product-card');
    
    if (categoryButtons.length > 0 && productCards.length > 0) {
        categoryButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons
                categoryButtons.forEach(btn => {
                    btn.classList.remove('bg-gizmo-neon', 'text-gizmo-black');
                    btn.classList.add('bg-transparent', 'border', 'border-gizmo-neon', 'text-gizmo-neon');
                });
                
                // Add active class to clicked button
                this.classList.remove('bg-transparent', 'border', 'border-gizmo-neon', 'text-gizmo-neon');
                this.classList.add('bg-gizmo-neon', 'text-gizmo-black');
                
                const category = this.getAttribute('data-category');
                
                // Filter products
                filterProducts(category);
            });
        });
    }
    
    function filterProducts(category) {
        let hasVisibleProducts = false;
        
        productCards.forEach(card => {
            const cardCategory = card.getAttribute('data-category');
            
            if (category === 'all' || cardCategory === category) {
                card.style.display = '';
                hasVisibleProducts = true;
            } else {
                card.style.display = 'none';
            }
        });
        
        // Show/hide the "no results" message if present
        const noResultsMessage = document.getElementById('no-results');
        if (noResultsMessage) {
            if (hasVisibleProducts) {
                noResultsMessage.classList.add('hidden');
            } else {
                noResultsMessage.classList.remove('hidden');
            }
        }
    }

    // FAQ accordion functionality on contact page
    const faqToggles = document.querySelectorAll('.faq-toggle');
    
    if (faqToggles.length > 0) {
        faqToggles.forEach(toggle => {
            toggle.addEventListener('click', function() {
                const content = this.nextElementSibling;
                const icon = this.querySelector('svg');
                
                // Toggle content visibility
                if (content.classList.contains('hidden')) {
                    content.classList.remove('hidden');
                    icon.classList.add('rotate-180');
                } else {
                    content.classList.add('hidden');
                    icon.classList.remove('rotate-180');
                }
            });
        });
    }

    // Contact form submission handling
    const contactForm = document.getElementById('contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            const formData = new FormData(contactForm);
            const formDataObj = {};
            
            formData.forEach((value, key) => {
                formDataObj[key] = value;
            });
            
            // Log form data to console (as required - no backend)
            console.log('Form submission:', formDataObj);
            
            // Show success message
            const successMessage = document.getElementById('form-success');
            if (successMessage) {
                successMessage.classList.remove('hidden');
                
                // Reset form
                contactForm.reset();
                
                // Hide success message after 5 seconds
                setTimeout(() => {
                    successMessage.classList.add('hidden');
                }, 5000);
            }
        });
    }

    // Cookie consent handling
    const cookieConsent = document.getElementById('cookie-consent');
    const acceptCookiesBtn = document.getElementById('accept-cookies');
    const rejectCookiesBtn = document.getElementById('reject-cookies');
    
    if (cookieConsent && acceptCookiesBtn && rejectCookiesBtn) {
        // Check if user has already made a choice
        if (!localStorage.getItem('cookie-consent-given')) {
            // Show the cookie consent popup after a short delay
            setTimeout(() => {
                cookieConsent.style.transform = 'translateY(0)';
            }, 1000);
        }
        
        // Handle accept button click
        acceptCookiesBtn.addEventListener('click', function() {
            localStorage.setItem('cookie-consent-given', 'accepted');
            cookieConsent.style.transform = 'translateY(100%)';
            console.log('Cookies accepted');
        });
        
        // Handle reject button click
        rejectCookiesBtn.addEventListener('click', function() {
            localStorage.setItem('cookie-consent-given', 'rejected');
            cookieConsent.style.transform = 'translateY(100%)';
            console.log('Cookies rejected');
        });
    }
});