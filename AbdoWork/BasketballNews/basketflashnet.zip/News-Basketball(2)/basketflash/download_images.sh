#!/bin/bash

# Create images directories if they don't exist
mkdir -p images/{hero,players,news,teams,general}

# Function to download and convert image
download_and_convert() {
    local url=$1
    local output=$2
    local folder=${3:-"general"}
    
    echo "Downloading $output from $url to images/$folder/$output.webp"
    
    # Download image
    wget -q -O "temp.jpg" "$url" || {
        echo "Failed to download $url"
        return 1
    }
    
    # Convert to WebP with optimization
    cwebp -quiet -q 80 "temp.jpg" -o "images/$folder/$output.webp" || {
        echo "Failed to convert $output to WebP"
        rm -f temp.jpg
        return 1
    }
    
    # Remove temporary file
    rm -f temp.jpg
    echo "Successfully downloaded and converted $output"
}

# Hero images
download_and_convert "https://images.unsplash.com/photo-1504450758481-7338eba7524a" "basketball-court" "hero"
download_and_convert "https://images.unsplash.com/photo-1546519638-68e109acd27d" "basketball-stadium" "hero"
download_and_convert "https://images.unsplash.com/photo-1518063319789-7217e6706b04" "basketball-game" "hero"

# Player images
download_and_convert "https://cdn.nba.com/headshots/nba/latest/1040x760/203507.png" "giannis" "players"
download_and_convert "https://cdn.nba.com/headshots/nba/latest/1040x760/201939.png" "curry" "players"
download_and_convert "https://cdn.nba.com/headshots/nba/latest/260x190/201142.png" "durant" "players"
download_and_convert "https://cdn.nba.com/headshots/nba/latest/260x190/1628369.png" "tatum" "players"
download_and_convert "https://cdn.nba.com/headshots/nba/latest/260x190/2544.png" "lebron" "players"
download_and_convert "https://cdn.nba.com/headshots/nba/latest/260x190/1629029.png" "doncic" "players"
download_and_convert "https://cdn.nba.com/headshots/nba/latest/260x190/1629027.png" "young" "players"
download_and_convert "https://cdn.nba.com/headshots/nba/latest/260x190/201935.png" "harden" "players"

# News images
download_and_convert "https://images.unsplash.com/photo-1518407613690-d9fc990e795f" "warriors-game" "news"
download_and_convert "https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4" "injury-update" "news"
download_and_convert "https://images.unsplash.com/photo-1519861531473-9200262188bf" "player-analysis" "news"
download_and_convert "https://images.unsplash.com/photo-1608245449230-4ac19066d2d0" "championship-game" "news"
download_and_convert "https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff" "training-session" "news"
download_and_convert "https://images.unsplash.com/photo-1519861155730-0b5fbf0dd889" "draft-picks" "news"

# Team logos
download_and_convert "https://cdn.nba.com/logos/nba/1610612747/global/L/logo.svg" "lakers" "teams"
download_and_convert "https://cdn.nba.com/logos/nba/1610612738/global/L/logo.svg" "celtics" "teams"
download_and_convert "https://cdn.nba.com/logos/nba/1610612744/global/L/logo.svg" "warriors" "teams"
download_and_convert "https://cdn.nba.com/logos/nba/1610612749/global/L/logo.svg" "bucks" "teams"

# General images
download_and_convert "https://images.unsplash.com/photo-1515523110800-9415d13b84a8" "basketball-close" "general"
download_and_convert "https://images.unsplash.com/photo-1577471488278-16eec37ffcc2" "basketball-hoop" "general"
download_and_convert "https://images.unsplash.com/photo-1627627256672-027a4613d028" "basketball-shoes" "general"

echo "All basketball images have been downloaded and converted to WebP format"
