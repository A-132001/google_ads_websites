import os
import requests
from concurrent.futures import ThreadPoolExecutor

# Create directory if it doesn't exist
output_dir = '/media/abdo-sabry/Eng Abdo1/itiCourse/staticWebsites/News-Basketball(2)/basketflash/images/new-design'
os.makedirs(output_dir, exist_ok=True)

# List of NBA team logos to download (using NBA CDN)
team_logos = [
    ('team-lakers.webp', 'https://cdn.nba.com/logos/nba/1610612747/primary/L/logo.svg'),
    ('team-celtics.webp', 'https://cdn.nba.com/logos/nba/1610612738/primary/L/logo.svg'),
    ('team-warriors.webp', 'https://cdn.nba.com/logos/nba/1610612744/primary/L/logo.svg'),
    ('team-bucks.webp', 'https://cdn.nba.com/logos/nba/1610612749/primary/L/logo.svg'),
    ('team-nets.webp', 'https://cdn.nba.com/logos/nba/1610612751/primary/L/logo.svg'),
    ('team-suns.webp', 'https://cdn.nba.com/logos/nba/1610612756/primary/L/logo.svg'),
]

def download_image(image_info):
    filename, url = image_info
    output_path = os.path.join(output_dir, filename)
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, stream=True)
        response.raise_for_status()
        
        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        print(f"Successfully downloaded {filename}")
        return True
    except Exception as e:
        print(f"Failed to download {filename}: {e}")
        return False

# Download images in parallel
with ThreadPoolExecutor(max_workers=4) as executor:
    results = list(executor.map(download_image, team_logos))

print(f"Downloaded {sum(results)} out of {len(team_logos)} team logos")
