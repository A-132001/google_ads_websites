// Mobile menu functionality
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    
    // Toggle mobile menu
    mobileMenuButton.addEventListener('click', function() {
        mobileMenu.classList.toggle('hidden');
    });

    // Close mobile menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!mobileMenu.contains(event.target) && !mobileMenuButton.contains(event.target)) {
            mobileMenu.classList.add('hidden');
        }
    });

    // Handle cookie consent
    const cookieBanner = document.getElementById('cookie-banner');
    const acceptCookieButton = document.querySelector('#cookie-banner button');

    // Check if user has already accepted cookies
    if (!localStorage.getItem('cookiesAccepted')) {
        cookieBanner.classList.remove('hidden');
    }

    // Handle cookie acceptance
    acceptCookieButton.addEventListener('click', function() {
        localStorage.setItem('cookiesAccepted', 'true');
        cookieBanner.classList.add('hidden');
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Navbar scroll behavior
    const nav = document.querySelector('nav');
    let lastScroll = 0;

    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;

        // Add shadow and background opacity based on scroll
        if (currentScroll > 0) {
            nav.classList.add('shadow-md');
            nav.classList.remove('bg-white/90');
            nav.classList.add('bg-white/95');
        } else {
            nav.classList.remove('shadow-md');
            nav.classList.add('bg-white/90');
            nav.classList.remove('bg-white/95');
        }

        // Hide/show navbar based on scroll direction
        if (currentScroll > lastScroll && currentScroll > 80) {
            // Scrolling down & past navbar
            nav.style.transform = 'translateY(-100%)';
            mobileMenu.classList.add('hidden');
        } else {
            // Scrolling up
            nav.style.transform = 'translateY(0)';
        }

        lastScroll = currentScroll;
    });
});

// Search functionality
const searchInput = document.getElementById('search');
if (searchInput) {
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const searchTerm = this.value.trim().toLowerCase();
            if (searchTerm) {
                // Redirect to search results page (you can modify this based on your needs)
                window.location.href = `/guides?search=${encodeURIComponent(searchTerm)}`;
            }
        }
    });
}

// Add smooth transitions for all interactive elements
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a, button').forEach(element => {
        element.classList.add('transition-all', 'duration-300');
    });
});
