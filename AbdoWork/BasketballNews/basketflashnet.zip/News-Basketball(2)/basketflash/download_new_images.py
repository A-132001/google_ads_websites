import os
import requests
from concurrent.futures import ThreadPoolExecutor

# Create directory if it doesn't exist
output_dir = '/media/abdo-sabry/Eng Abdo1/itiCourse/staticWebsites/News-Basketball(2)/basketflash/images/new-design'
os.makedirs(output_dir, exist_ok=True)

# List of images to download
images = [
    # Basketball court and game images
    ('basketball-arena.webp', 'https://images.unsplash.com/photo-1504450758481-7338eba7524a?q=80&w=1000&auto=format&fit=crop'),
    ('basketball-game.webp', 'https://images.unsplash.com/photo-1518407613690-d9fc990e795f?q=80&w=1000&auto=format&fit=crop'),
    ('basketball-court.webp', 'https://images.unsplash.com/photo-1519861531473-9200262188bf?q=80&w=1000&auto=format&fit=crop'),
    ('basketball-action.webp', 'https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=1000&auto=format&fit=crop'),
    ('basketball-stadium.webp', 'https://images.unsplash.com/photo-1504297050568-910d24c426d3?q=80&w=1000&auto=format&fit=crop'),
    
    # Team logos (as webp)
    ('team-lakers.webp', 'https://assets.stickpng.com/images/58419cf6a6515b1e0ad75a61.png'),
    ('team-celtics.webp', 'https://assets.stickpng.com/images/58419c7ba6515b1e0ad75a5f.png'),
    ('team-warriors.webp', 'https://assets.stickpng.com/images/58419ce2a6515b1e0ad75a60.png'),
    ('team-bucks.webp', 'https://assets.stickpng.com/images/58419c6aa6515b1e0ad75a5e.png'),
    ('team-nets.webp', 'https://assets.stickpng.com/images/58419c8da6515b1e0ad75a5c.png'),
    ('team-suns.webp', 'https://assets.stickpng.com/images/58419d52a6515b1e0ad75a6d.png'),
    
    # Additional basketball-related images
    ('basketball-closeup.webp', 'https://images.unsplash.com/photo-1608245449230-4ac19066d2d0?q=80&w=1000&auto=format&fit=crop'),
    ('basketball-hoop.webp', 'https://images.unsplash.com/photo-1519861155730-0b5fbf0dd889?q=80&w=1000&auto=format&fit=crop'),
    ('basketball-fans.webp', 'https://images.unsplash.com/photo-1515523110800-9415d13b84a8?q=80&w=1000&auto=format&fit=crop'),
    ('basketball-jersey.webp', 'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4?q=80&w=1000&auto=format&fit=crop'),
    
    # News page specific images
    ('news-hero.webp', 'https://images.unsplash.com/photo-1587329310686-91414b8e3cb7?q=80&w=1000&auto=format&fit=crop'),
    ('news-player-interview.webp', 'https://images.unsplash.com/photo-1519766304817-4f37bda74a26?q=80&w=1000&auto=format&fit=crop'),
    ('news-press-conference.webp', 'https://images.unsplash.com/photo-1603099080454-df5a1a6f4d0e?q=80&w=1000&auto=format&fit=crop'),
    ('news-coach.webp', 'https://images.unsplash.com/photo-1526232761682-d26e03ac148e?q=80&w=1000&auto=format&fit=crop'),
    ('news-celebration.webp', 'https://images.unsplash.com/photo-1562077981-4d7eafd44932?q=80&w=1000&auto=format&fit=crop'),
    ('news-analysis.webp', 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1000&auto=format&fit=crop'),
    ('news-draft.webp', 'https://images.unsplash.com/photo-1560012307-9b1a38a5a72b?q=80&w=1000&auto=format&fit=crop'),
    ('news-injury.webp', 'https://images.unsplash.com/photo-1544972917-3529b113a469?q=80&w=1000&auto=format&fit=crop'),
    ('news-trade.webp', 'https://images.unsplash.com/photo-1569779213435-ba3167ecfcbe?q=80&w=1000&auto=format&fit=crop'),
    ('basketball-pattern.webp', 'https://img.freepik.com/premium-vector/basketball-seamless-pattern-background_7814-261.jpg?w=1000'),
]

def download_image(image_info):
    filename, url = image_info
    output_path = os.path.join(output_dir, filename)
    
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        
        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        print(f"Successfully downloaded {filename}")
        return True
    except Exception as e:
        print(f"Failed to download {filename}: {e}")
        return False

# Download images in parallel
with ThreadPoolExecutor(max_workers=4) as executor:
    results = list(executor.map(download_image, images))

print(f"Downloaded {sum(results)} out of {len(images)} images")
