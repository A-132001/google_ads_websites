import requests
import os

def download_image(url, filename):
    response = requests.get(url)
    if response.status_code == 200:
        with open(filename, 'wb') as f:
            f.write(response.content)
        print(f"Downloaded {filename}")
    else:
        print(f"Failed to download {filename}")

# Create images directory if it doesn't exist
os.makedirs('assets/images', exist_ok=True)

# Download basketball images from Unsplash
images = [
    {
        'url': 'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=800&q=80&fm=webp',
        'filename': 'assets/images/basketball.webp'
    },
    {
        'url': 'https://images.unsplash.com/photo-1519861531473-9200262188bf?w=800&q=80&fm=webp',
        'filename': 'assets/images/basketball-game.webp'
    },
    {
        'url': 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800&q=80&fm=webp',
        'filename': 'assets/images/basketball-trophy.webp'
    }
]

for image in images:
    download_image(image['url'], image['filename']) 