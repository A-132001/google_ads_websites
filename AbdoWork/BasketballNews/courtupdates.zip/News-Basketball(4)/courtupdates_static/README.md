# CourtUpdates - Basketball News Website (Tailwind CSS Version)

A modern, SEO-friendly, and high-performance static website delivering comprehensive NBA coverage through an interactive and engaging web experience.

## Overview

CourtUpdates is a static HTML website built with Tailwind CSS that focuses on delivering basketball news, player statistics, and analysis. The site is designed to be fast-loading, responsive across all devices, and optimized for search engines.

## Features

- **Responsive Design**: Looks great on desktop, tablet, and mobile devices
- **Basketball News**: Comprehensive coverage of basketball news and events
- **Player Statistics**: Detailed player stats and performance metrics
- **Interactive Elements**: Search functionality, cookie consent, mobile menu
- **SEO Optimized**: Clean HTML structure with proper meta tags
- **No Backend Required**: 100% static, can be hosted anywhere

## Pages

- **Home**: Main landing page with featured news and stats highlights
- **News**: Archive of basketball news articles and updates
- **Player Stats**: Comprehensive player statistics and metrics
- **About**: Information about CourtUpdates and its mission
- **Contact**: Contact form and company information
- **Download**: Page for downloading the static site package

## Technology Stack

- **HTML5**: Semantic structure for better accessibility and SEO
- **Tailwind CSS**: Utility-first CSS framework via CDN
- **JavaScript**: Vanilla JS for interactive elements
- **Font Awesome**: Icons for visual elements
- **Google Fonts**: Typography (Inter & Montserrat)

## Getting Started

To use this website locally:

1. Download or clone this repository
2. Open `index.html` in your web browser

No build steps, compilation, or server setup required!

## Hosting

This static site can be hosted on any web hosting service that supports HTML/CSS/JS files:

- GitHub Pages
- Netlify
- Vercel
- Amazon S3
- Traditional web hosting
- Local file system (simply open index.html)

## Customization

### Changing Colors

The site uses Tailwind CSS with a customized blue-based color palette. To change the primary color, modify the `tailwind.config` script in each HTML file:

```js
tailwind.config = {
  theme: {
    extend: {
      colors: {
        primary: {
          // Your custom color values here
        }
      }
    }
  }
}
```

### Adding Pages

To add a new page:

1. Create a new directory with the page name (e.g., `new-page/`)
2. Add an `index.html` file inside the directory
3. Copy the structure from an existing page
4. Update the content
5. Add navigation links to the new page in the header and footer of all pages

## Creating a Download Package

To create a ZIP file of the entire website for distribution:

1. Run the included script: `bash create_zip.sh`
2. This will generate `courtupdates_static.zip` in the root directory
3. The ZIP file can be distributed for others to download and use

## License

MIT License - Feel free to use, modify and distribute as needed.

## Credits

- Font Awesome for icons
- Google Fonts for typography
- Tailwind CSS for styling

---

Created with ❤️ for basketball fans everywhere.