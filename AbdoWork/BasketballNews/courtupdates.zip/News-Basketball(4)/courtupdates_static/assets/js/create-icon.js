const canvas = document.createElement('canvas');
canvas.width = 32;
canvas.height = 32;
const ctx = canvas.getContext('2d');

// Draw basketball
ctx.beginPath();
ctx.arc(16, 16, 15, 0, Math.PI * 2);
ctx.fillStyle = '#f97316'; // Orange color
ctx.fill();
ctx.strokeStyle = '#000';
ctx.lineWidth = 2;
ctx.stroke();

// Draw lines
ctx.beginPath();
ctx.moveTo(1, 16);
ctx.lineTo(31, 16);
ctx.moveTo(16, 1);
ctx.lineTo(16, 31);
ctx.stroke();

// Convert to WebP
const webpData = canvas.toDataURL('image/webp');
console.log(webpData); 