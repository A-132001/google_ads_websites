/**
 * CourtUpdates - Basketball News Website
 * Main JavaScript file
 */

document.addEventListener('DOMContentLoaded', function() {
  // Initialize all interactive components
  initMobileMenu();
  initCookieConsent();
  initSearchFunctionality();
  initFaqAccordion();
  initContactForm();
});

/**
 * Initialize mobile menu toggle functionality
 */
function initMobileMenu() {
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const navMenu = document.getElementById('mobile-menu');
  
  if (mobileMenuBtn && navMenu) {
    mobileMenuBtn.addEventListener('click', function() {
      navMenu.classList.toggle('hidden');
      
      // Toggle between menu and close icons
      const icon = this.querySelector('i');
      if (icon.classList.contains('fa-bars')) {
        icon.classList.remove('fa-bars');
        icon.classList.add('fa-times');
      } else {
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
      }
    });
  }
}

/**
 * Initialize cookie consent functionality
 */
function initCookieConsent() {
  const cookieConsent = document.getElementById('cookie-consent');
  const acceptCookies = document.getElementById('accept-cookies');
  const rejectCookies = document.getElementById('reject-cookies');
  
  // Check if cookie consent was already given
  if (cookieConsent && !localStorage.getItem('cookieConsent')) {
    // Show the cookie consent banner after a short delay
    setTimeout(function() {
      cookieConsent.classList.remove('hidden');
    }, 1000);
    
    // Event listeners for buttons
    if (acceptCookies) {
      acceptCookies.addEventListener('click', function() {
        setCookieConsent('accepted');
      });
    }
    
    if (rejectCookies) {
      rejectCookies.addEventListener('click', function() {
        setCookieConsent('rejected');
      });
    }
  }
}

/**
 * Set cookie consent choice and hide the banner
 * @param {string} choice - The user's choice ('accepted' or 'rejected')
 */
function setCookieConsent(choice) {
  localStorage.setItem('cookieConsent', choice);
  
  const cookieConsent = document.getElementById('cookie-consent');
  if (cookieConsent) {
    cookieConsent.classList.add('hidden');
  }
  
  console.log(`Cookies ${choice}`);
}

/**
 * Initialize search form functionality
 */
function initSearchFunctionality() {
  const searchForm = document.querySelector('.search-form');
  const searchInput = document.getElementById('search-input');
  const searchResults = document.getElementById('search-results');
  const newsItems = document.querySelectorAll('.news-item');
  
  if (searchForm && searchInput) {
    searchForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const searchTerm = searchInput.value.trim().toLowerCase();
      
      if (!searchTerm) {
        // If search is empty, show all news items
        if (newsItems) {
          newsItems.forEach(item => {
            item.classList.remove('hidden');
          });
        }
        
        if (searchResults) {
          searchResults.classList.add('hidden');
        }
        return;
      }
      
      console.log('Searching for:', searchTerm);
      
      // If on news page, filter the news items
      if (newsItems && newsItems.length > 0) {
        let matchCount = 0;
        
        newsItems.forEach(item => {
          const title = item.querySelector('h3').textContent.toLowerCase();
          const content = item.querySelector('p').textContent.toLowerCase();
          
          if (title.includes(searchTerm) || content.includes(searchTerm)) {
            item.classList.remove('hidden');
            matchCount++;
          } else {
            item.classList.add('hidden');
          }
        });
        
        // Show search results count
        if (searchResults) {
          searchResults.textContent = `Found ${matchCount} result${matchCount !== 1 ? 's' : ''} for "${searchTerm}"`;
          searchResults.classList.remove('hidden');
        }
      } else {
        // If not on news page, just show an alert
        alert(`Search functionality would search for: ${searchTerm}`);
      }
    });
  }
}

/**
 * Initialize FAQ accordion functionality (for Contact page)
 */
function initFaqAccordion() {
  const faqItems = document.querySelectorAll('.faq-item');
  
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    
    if (question) {
      question.addEventListener('click', function() {
        const answer = item.querySelector('.faq-answer');
        const icon = this.querySelector('i');
        
        // Toggle current item
        answer.classList.toggle('hidden');
        
        // Toggle icon
        if (icon) {
          if (icon.classList.contains('fa-plus')) {
            icon.classList.remove('fa-plus');
            icon.classList.add('fa-minus');
          } else {
            icon.classList.remove('fa-minus');
            icon.classList.add('fa-plus');
          }
        }
        
        // Close other items
        faqItems.forEach(otherItem => {
          if (otherItem !== item) {
            const otherAnswer = otherItem.querySelector('.faq-answer');
            const otherIcon = otherItem.querySelector('.faq-question i');
            
            if (otherAnswer) {
              otherAnswer.classList.add('hidden');
            }
            
            if (otherIcon && otherIcon.classList.contains('fa-minus')) {
              otherIcon.classList.remove('fa-minus');
              otherIcon.classList.add('fa-plus');
            }
          }
        });
      });
    }
  });
}

/**
 * Initialize contact form functionality
 */
function initContactForm() {
  const contactForm = document.getElementById('contact-form');
  
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Get form data
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const message = document.getElementById('message').value;
      
      // Validate form
      if (!name || !email || !message) {
        alert('Please fill in all fields');
        return;
      }
      
      // Log form submission (as per requirements, since there's no backend)
      console.log('Form submission:', {
        name,
        email,
        message,
        timestamp: new Date().toISOString()
      });
      
      // Show success message
      alert('Your message has been sent! (This is a demo, so the message is just logged to the console)');
      
      // Reset form
      contactForm.reset();
    });
  }
}