/**
 * DunkWire Basketball Website Main JavaScript
 */

// DOM Elements
const mobileMenuButton = document.getElementById('mobile-menu-button');
const mobileMenu = document.getElementById('mobile-menu');
const searchButton = document.getElementById('search-button');
const searchPanel = document.getElementById('search-panel');
const cookieBanner = document.getElementById('cookie-banner');
const cookieAccept = document.getElementById('cookie-accept');
const cookieSettings = document.getElementById('cookie-settings');

// Mobile Menu Toggle
if (mobileMenuButton && mobileMenu) {
    mobileMenuButton.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });
}

// Search Panel Toggle
if (searchButton && searchPanel) {
    searchButton.addEventListener('click', () => {
        searchPanel.classList.toggle('hidden');
    });
}

// Cookie Banner
if (cookieBanner && cookieAccept && cookieSettings) {
    // Check if user has already accepted cookies
    if (!localStorage.getItem('cookiesAccepted')) {
        cookieBanner.classList.remove('hidden');
    } else {
        cookieBanner.classList.add('hidden');
    }
    
    cookieAccept.addEventListener('click', () => {
        localStorage.setItem('cookiesAccepted', 'true');
        cookieBanner.classList.add('hidden');
    });
    
    cookieSettings.addEventListener('click', () => {
        // Could link to a cookie settings page
        window.location.href = 'cookie-policy/index.html';
    });
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Initialize animations for elements when they come into view
document.addEventListener('DOMContentLoaded', () => {
    const animateElements = document.querySelectorAll('.animate-on-scroll');
    
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };
    
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    animateElements.forEach(element => {
        observer.observe(element);
    });
    
    // Check for URL parameters on page load
    initializeFromURLParams();
});

// Initialize filters from URL parameters
function initializeFromURLParams() {
    const urlParams = new URLSearchParams(window.location.search);
    
    // Category filter for news page
    const category = urlParams.get('category');
    if (category && window.filterByCategory) {
        filterByCategory(category);
    }
    
    // Position and team filters for player stats page
    const position = urlParams.get('position');
    const team = urlParams.get('team');
    
    const positionFilter = document.getElementById('position-filter');
    const teamFilter = document.getElementById('team-filter');
    
    if (position && positionFilter) {
        positionFilter.value = position;
    }
    
    if (team && teamFilter) {
        teamFilter.value = team;
    }
    
    if ((position || team) && window.filterPlayers) {
        filterPlayers();
    }
}

// Player Search and Filtering
if (document.getElementById('player-stats-body')) {
    const playerSearch = document.getElementById('player-search');
    const positionFilter = document.getElementById('position-filter');
    const teamFilter = document.getElementById('team-filter');
    const sortBySelect = document.getElementById('sort-by');
    const applyFilters = document.getElementById('apply-filters');
    const playerStatsBody = document.getElementById('player-stats-body');
    const noResults = document.getElementById('no-results');
    
    if (applyFilters) {
        applyFilters.addEventListener('click', filterPlayers);
    }
    
    if (playerSearch) {
        playerSearch.addEventListener('keyup', (e) => {
            if (e.key === 'Enter') {
                filterPlayers();
            }
        });
    }
    
    // Initialize the table with default sorting (PPG)
    if (playerStatsBody) {
        sortTable('ppg');
    }
    
    // Global function for filtering players
    window.filterPlayers = function() {
        const searchTerm = playerSearch ? playerSearch.value.toLowerCase() : '';
        const position = positionFilter ? positionFilter.value : '';
        const team = teamFilter ? teamFilter.value : '';
        const sortBy = sortBySelect ? sortBySelect.value : 'ppg';
        
        const rows = playerStatsBody.querySelectorAll('tr');
        let visibleCount = 0;
        
        // Filter rows
        rows.forEach(row => {
            const playerName = row.querySelector('td:first-child').textContent.toLowerCase();
            const rowTeam = row.dataset.team;
            const rowPosition = row.dataset.position;
            
            const matchesSearch = searchTerm === '' || playerName.includes(searchTerm);
            const matchesPosition = position === '' || rowPosition === position;
            const matchesTeam = team === '' || rowTeam === team;
            
            if (matchesSearch && matchesPosition && matchesTeam) {
                row.classList.remove('hidden');
                visibleCount++;
            } else {
                row.classList.add('hidden');
            }
        });
        
        // Show/hide no results message
        if (noResults) {
            if (visibleCount === 0) {
                noResults.classList.remove('hidden');
            } else {
                noResults.classList.add('hidden');
            }
        }
        
        // Sort visible rows
        sortTable(sortBy);
    };
    
    // Global function for resetting filters
    window.resetFilters = function() {
        if (playerSearch) playerSearch.value = '';
        if (positionFilter) positionFilter.value = '';
        if (teamFilter) teamFilter.value = '';
        if (sortBySelect) sortBySelect.value = 'ppg';
        
        const rows = playerStatsBody.querySelectorAll('tr');
        rows.forEach(row => row.classList.remove('hidden'));
        
        if (noResults) {
            noResults.classList.add('hidden');
        }
        
        sortTable('ppg');
    };
    
    // Global function for sorting the table
    window.sortTable = function(stat) {
        const tbody = document.getElementById('player-stats-body');
        if (!tbody) return;
        
        const rows = Array.from(tbody.querySelectorAll('tr:not(.hidden)'));
        
        // Sort by the selected stat
        rows.sort((a, b) => {
            const aValue = parseFloat(a.querySelector(`td[data-${stat}]`).dataset[stat]);
            const bValue = parseFloat(b.querySelector(`td[data-${stat}]`).dataset[stat]);
            return bValue - aValue; // Descending order
        });
        
        // Re-append rows in the sorted order
        rows.forEach(row => {
            tbody.appendChild(row);
        });
    };
}

// Category Filtering for News
if (document.getElementById('articles-container')) {
    // Global function for filtering by category
    window.filterByCategory = function(category) {
        const articles = document.querySelectorAll('#articles-container article');
        const noResults = document.getElementById('no-results');
        const categoryButtons = document.querySelectorAll('.category-filter');
        
        let visibleCount = 0;
        
        // Update active button style
        if (categoryButtons) {
            categoryButtons.forEach(button => {
                if ((category === null && button.dataset.category === '') || 
                    (button.dataset.category === category)) {
                    button.classList.add('bg-dunk-blue', 'text-white');
                    button.classList.remove('bg-dunk-gray-100', 'text-dunk-gray-700', 'hover:bg-dunk-gray-200');
                } else {
                    button.classList.remove('bg-dunk-blue', 'text-white');
                    button.classList.add('bg-dunk-gray-100', 'text-dunk-gray-700', 'hover:bg-dunk-gray-200');
                }
            });
        }
        
        // Filter articles
        articles.forEach(article => {
            if (category === null || article.dataset.category === category) {
                article.classList.remove('hidden');
                visibleCount++;
            } else {
                article.classList.add('hidden');
            }
        });
        
        // Show/hide no results message
        if (noResults) {
            if (visibleCount === 0) {
                noResults.classList.remove('hidden');
            } else {
                noResults.classList.add('hidden');
            }
        }
    };
}