# DunkWire - Static Basketball News Website

This is a modern, SEO-friendly, high-performance static website for basketball news and player statistics.

## Features

- Responsive design using Tailwind CSS
- Basketball-themed SVG graphics
- Interactive player statistics with sorting and filtering
- News articles with category filtering
- Mobile-friendly navigation
- Cookie consent implementation
- Clean, modern design optimized for performance

## Pages

- Home (`index.html`): Main landing page with featured content
- News (`news/index.html`): Basketball news articles with category filtering
- Player Stats (`player-stats/index.html`): Interactive player statistics table
- About (`about/index.html`): Information about DunkWire
- Contact (`contact/index.html`): Contact form and information
- Privacy Policy (`privacy/index.html`): Privacy information
- Cookie Policy (`cookie-policy/index.html`): Cookie usage information

## Assets

- CSS: Located in the `css` directory
- JavaScript: Located in the `js` directory
- Images: SVG graphics in the `images` directory

## Technologies Used

- HTML5
- CSS3 with Tailwind CSS (via CDN)
- Vanilla JavaScript (no dependencies)
- SVG for graphics

## Deployment

This is a fully static website that can be deployed to any web hosting service or CDN.

## Local Development

To run the website locally, simply open any of the HTML files in a web browser.

---

Created for basketball fans everywhere. © 2025 DunkWire