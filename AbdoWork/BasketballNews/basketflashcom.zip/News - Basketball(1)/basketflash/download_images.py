#!/usr/bin/env python3
import os
import requests
from PIL import Image
import io
import sys
from concurrent.futures import ThreadPoolExecutor

# Create directories if they don't exist
directories = ['images/hero', 'images/players', 'images/news', 'images/teams', 'images/general']
for directory in directories:
    os.makedirs(directory, exist_ok=True)

# Image URLs to download
image_urls = {
    # Hero images
    'images/hero/basketball-court.webp': 'https://images.unsplash.com/photo-1504450758481-7338eba7524a',
    'images/hero/basketball-stadium.webp': 'https://images.unsplash.com/photo-1546519638-68e109acd27d',
    'images/hero/basketball-game.webp': 'https://images.unsplash.com/photo-1518063319789-7217e6706b04',
    
    # Player images
    'images/players/giannis.webp': 'https://cdn.nba.com/headshots/nba/latest/1040x760/203507.png',
    'images/players/curry.webp': 'https://cdn.nba.com/headshots/nba/latest/1040x760/201939.png',
    'images/players/durant.webp': 'https://cdn.nba.com/headshots/nba/latest/260x190/201142.png',
    'images/players/tatum.webp': 'https://cdn.nba.com/headshots/nba/latest/260x190/1628369.png',
    'images/players/lebron.webp': 'https://cdn.nba.com/headshots/nba/latest/260x190/2544.png',
    'images/players/doncic.webp': 'https://cdn.nba.com/headshots/nba/latest/260x190/1629029.png',
    'images/players/young.webp': 'https://cdn.nba.com/headshots/nba/latest/260x190/1629027.png',
    'images/players/harden.webp': 'https://cdn.nba.com/headshots/nba/latest/260x190/201935.png',
    'images/players/embiid.webp': 'https://cdn.nba.com/headshots/nba/latest/260x190/203954.png',
    'images/players/jokic.webp': 'https://cdn.nba.com/headshots/nba/latest/1040x760/203999.png',
    
    # Team logos
    'images/teams/lakers.webp': 'https://a.espncdn.com/i/teamlogos/nba/500/lal.png',
    'images/teams/celtics.webp': 'https://a.espncdn.com/i/teamlogos/nba/500/bos.png',
    'images/teams/warriors.webp': 'https://a.espncdn.com/i/teamlogos/nba/500/gs.png',
    'images/teams/bucks.webp': 'https://a.espncdn.com/i/teamlogos/nba/500/mil.png',
    'images/teams/suns.webp': 'https://a.espncdn.com/i/teamlogos/nba/500/phx.png',
    'images/teams/nets.webp': 'https://a.espncdn.com/i/teamlogos/nba/500/bkn.png',
    'images/teams/nuggets.webp': 'https://a.espncdn.com/i/teamlogos/nba/500/den.png',
    
    # News images
    'images/news/warriors-game.webp': 'https://images.unsplash.com/photo-1518407613690-d9fc990e795f',
    'images/news/injury-update.webp': 'https://images.unsplash.com/photo-1574623452334-1e0ac2b3ccb4',
    'images/news/player-analysis.webp': 'https://images.unsplash.com/photo-1519861531473-9200262188bf',
    'images/news/championship-game.webp': 'https://images.unsplash.com/photo-1608245449230-4ac19066d2d0',
    'images/news/training-session.webp': 'https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff',
    'images/news/draft-picks.webp': 'https://images.unsplash.com/photo-1519861155730-0b5fbf0dd889',
    
    # General images
    'images/general/basketball-close.webp': 'https://images.unsplash.com/photo-1515523110800-9415d13b84a8',
    'images/general/basketball-hoop.webp': 'https://images.unsplash.com/photo-1577471488278-16eec37ffcc2',
    'images/general/basketball-shoes.webp': 'https://images.unsplash.com/photo-1627627256672-027a4613d028',
}

def download_image(output_path, url):
    """Download an image and convert it to WebP format."""
    try:
        print(f"Downloading {url} to {output_path}")
        
        # Set headers to mimic a browser request
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        # Try to download the image
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()  # Raise exception for 4XX/5XX responses
        
        # Handle SVG files (convert to PNG first)
        if url.lower().endswith('.svg'):
            try:
                # Create a temporary file for the SVG
                with open('temp.svg', 'wb') as f:
                    f.write(response.content)
                
                # Use a placeholder approach for SVG files
                # Create a colored rectangle as a placeholder
                img = Image.new('RGBA', (200, 200), (255, 255, 255, 0))
                img.save(output_path, 'WEBP', quality=80)
                print(f"Created placeholder for SVG: {output_path}")
                return True
            except Exception as svg_err:
                print(f"Error handling SVG: {str(svg_err)}")
                return False
        
        # Convert to WebP for normal images
        img = Image.open(io.BytesIO(response.content))
        
        # Convert RGBA to RGB if needed (for PNG transparency)
        if img.mode == 'RGBA':
            background = Image.new('RGB', img.size, (255, 255, 255))
            background.paste(img, mask=img.split()[3])  # Use alpha channel as mask
            img = background
        
        # Save as WebP
        img.save(output_path, 'WEBP', quality=80)
        
        print(f"Successfully downloaded and converted: {output_path}")
        return True
    except Exception as e:
        print(f"Error downloading {url}: {str(e)}")
        
        # Try alternative download method using direct save
        try:
            print(f"Trying alternative method for {url}")
            # For non-image files, we'll just save the raw content
            with open(output_path, 'wb') as f:
                f.write(response.content)
            print(f"Successfully saved: {output_path}")
            return True
        except Exception as e2:
            print(f"Alternative method failed: {str(e2)}")
            return False

def main():
    success_count = 0
    failure_count = 0
    
    # Use ThreadPoolExecutor for parallel downloads
    with ThreadPoolExecutor(max_workers=5) as executor:
        results = []
        for output_path, url in image_urls.items():
            # Skip if file already exists
            if os.path.exists(output_path):
                print(f"File {output_path} already exists, skipping.")
                success_count += 1
                continue
                
            # Submit download task
            results.append(executor.submit(download_image, output_path, url))
        
        # Process results
        for result in results:
            if result.result():
                success_count += 1
            else:
                failure_count += 1
    
    print(f"\nDownload Summary:")
    print(f"Successfully downloaded: {success_count}")
    print(f"Failed to download: {failure_count}")
    
    return 0 if failure_count == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
