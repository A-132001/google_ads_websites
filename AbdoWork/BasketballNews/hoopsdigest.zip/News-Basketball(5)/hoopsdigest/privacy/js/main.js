/* HoopsDigest.net main JavaScript functionality */

document.addEventListener('DOMContentLoaded', function() {
  // Initialize all components
  initNavigation();
  initAnimation();
  initSearchForm();
  initCookieConsent();
  initStatsFilters();
  initContactForm();
  initNewsletterForm();
  initialLoadAnimations();
  checkDarkModePreference();
  
  // Check for specific URL parameters on load
  initializeFromURLParams();
});

/**
 * Handle Mobile Navigation
 */
function initNavigation() {
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  const overlay = document.getElementById('nav-overlay');
  
  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', function() {
      mobileMenu.classList.toggle('hidden');
      if (overlay) overlay.classList.toggle('hidden');
      document.body.classList.toggle('overflow-hidden');
      
      // Change aria-expanded state
      const expanded = mobileMenuBtn.getAttribute('aria-expanded') === 'true' || false;
      mobileMenuBtn.setAttribute('aria-expanded', !expanded);
    });
    
    // Close mobile menu when clicking outside
    if (overlay) {
      overlay.addEventListener('click', function() {
        mobileMenu.classList.add('hidden');
        overlay.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
        mobileMenuBtn.setAttribute('aria-expanded', 'false');
      });
    }
  }
  
  // Add scroll event to make header sticky with animation
  const header = document.querySelector('header');
  let lastScrollTop = 0;
  
  window.addEventListener('scroll', function() {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    if (scrollTop > 100) {
      header.classList.add('sticky-header', 'shadow-md', 'py-2');
      header.classList.remove('py-4');
      
      // Hide header when scrolling down, show when scrolling up
      if (scrollTop > lastScrollTop) {
        header.classList.add('header-hidden');
      } else {
        header.classList.remove('header-hidden');
      }
    } else {
      header.classList.remove('sticky-header', 'shadow-md', 'py-2', 'header-hidden');
      header.classList.add('py-4');
    }
    
    lastScrollTop = scrollTop;
  });
}

/**
 * Initialize animations for interactive elements
 */
function initAnimation() {
  // Add hover animations to cards and links
  document.querySelectorAll('.article-card, .player-card, .stat-card').forEach(card => {
    card.classList.add('hover-scale');
  });
  
  // Initialize AOS-like scroll animations manually
  const animatedElements = document.querySelectorAll('[data-animate]');
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const element = entry.target;
        const animation = element.getAttribute('data-animate');
        element.classList.add(animation);
        observer.unobserve(element);
      }
    });
  }, { threshold: 0.15 });
  
  animatedElements.forEach(element => {
    observer.observe(element);
  });
}

/**
 * Initial load animations
 */
function initialLoadAnimations() {
  // Add a short delay for the hero section to animate in
  const heroSection = document.querySelector('.hero-section');
  if (heroSection) {
    setTimeout(() => {
      heroSection.classList.add('loaded');
    }, 100);
  }
  
  // Stagger child elements in the featured section
  const featuredItems = document.querySelectorAll('.featured-item');
  featuredItems.forEach((item, index) => {
    setTimeout(() => {
      item.classList.add('loaded');
    }, 150 + (index * 100));
  });
}

/**
 * Cookie Consent Banner
 */
function initCookieConsent() {
  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('accept-cookies');
  const cookiePreference = localStorage.getItem('cookie-consent');
  
  if (cookieBanner && !cookiePreference) {
    setTimeout(() => {
      cookieBanner.classList.remove('hidden');
      cookieBanner.classList.add('flex');
    }, 1500);
    
    if (acceptBtn) {
      acceptBtn.addEventListener('click', function() {
        acceptCookies();
      });
    }
  }
  
  function acceptCookies() {
    localStorage.setItem('cookie-consent', 'accepted');
    cookieBanner.classList.add('hidden');
    cookieBanner.classList.remove('flex');
  }
}

/**
 * Search Form functionality
 */
function initSearchForm() {
  const searchForm = document.getElementById('search-form');
  const searchInput = document.getElementById('search-input');
  
  if (searchForm && searchInput) {
    searchForm.addEventListener('submit', function(event) {
      handleSearch(event);
    });
  }
  
  function handleSearch(event) {
    event.preventDefault();
    const searchTerm = searchInput.value.trim();
    
    if (searchTerm.length >= 2) {
      // Redirect to a search results page with the query parameter
      window.location.href = `/search.html?q=${encodeURIComponent(searchTerm)}`;
    } else {
      // Highlight the input to indicate more characters are needed
      searchInput.focus();
      searchInput.classList.add('border-red-500');
      
      setTimeout(() => {
        searchInput.classList.remove('border-red-500');
      }, 1000);
    }
  }
}

/**
 * Player Stats Filtering
 */
function initStatsFilters() {
  const statsTable = document.getElementById('stats-table');
  const filterButtons = document.querySelectorAll('[data-filter]');
  const sortButtons = document.querySelectorAll('[data-sort]');
  const searchInput = document.getElementById('player-search');
  
  if (statsTable && filterButtons) {
    // Filter by position
    filterButtons.forEach(button => {
      button.addEventListener('click', function() {
        const filter = this.getAttribute('data-filter');
        
        // Update active button style
        filterButtons.forEach(btn => btn.classList.remove('bg-hoops-green-600', 'text-white'));
        button.classList.add('bg-hoops-green-600', 'text-white');
        
        // Filter table rows
        const rows = statsTable.querySelectorAll('tbody tr');
        rows.forEach(row => {
          if (filter === 'all') {
            row.classList.remove('hidden');
          } else {
            const position = row.getAttribute('data-position');
            if (position === filter) {
              row.classList.remove('hidden');
            } else {
              row.classList.add('hidden');
            }
          }
        });
      });
    });
    
    // Sort by stat
    if (sortButtons) {
      sortButtons.forEach(button => {
        button.addEventListener('click', function() {
          const sortBy = this.getAttribute('data-sort');
          const isAscending = this.getAttribute('data-order') === 'asc';
          
          // Toggle sort order
          this.setAttribute('data-order', isAscending ? 'desc' : 'asc');
          
          // Update all buttons to show they're not active
          sortButtons.forEach(btn => {
            btn.classList.remove('text-hoops-green-600');
            btn.querySelector('svg')?.classList.add('opacity-50');
          });
          
          // Show this button as active
          button.classList.add('text-hoops-green-600');
          button.querySelector('svg')?.classList.remove('opacity-50');
          
          // Sort the table rows
          const tbody = statsTable.querySelector('tbody');
          const rows = Array.from(tbody.querySelectorAll('tr'));
          
          rows.sort((a, b) => {
            const aValue = parseFloat(a.querySelector(`[data-stat="${sortBy}"]`).textContent);
            const bValue = parseFloat(b.querySelector(`[data-stat="${sortBy}"]`).textContent);
            
            return isAscending ? aValue - bValue : bValue - aValue;
          });
          
          // Reappend rows in the new order
          rows.forEach(row => tbody.appendChild(row));
        });
      });
    }
    
    // Live search
    if (searchInput) {
      searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const rows = statsTable.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
          const playerName = row.querySelector('[data-player-name]').textContent.toLowerCase();
          const teamName = row.querySelector('[data-team]').textContent.toLowerCase();
          
          if (playerName.includes(searchTerm) || teamName.includes(searchTerm)) {
            row.classList.remove('hidden');
          } else {
            row.classList.add('hidden');
          }
        });
      });
    }
  }
}

/**
 * Contact Form handling
 */
function initContactForm() {
  const contactForm = document.getElementById('contact-form');
  
  if (contactForm) {
    contactForm.addEventListener('submit', function(event) {
      event.preventDefault();
      
      // Get form data
      const formData = new FormData(contactForm);
      const submitButton = contactForm.querySelector('button[type="submit"]');
      const formStatus = document.getElementById('form-status');
      
      // Show loading state
      if (submitButton) {
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="basketball-loader inline-block mr-2"></span> Sending...';
      }
      
      // Simulate form submission
      setTimeout(() => {
        // Reset form
        contactForm.reset();
        
        // Show success message
        if (formStatus) {
          formStatus.textContent = 'Your message has been sent! We\'ll get back to you soon.';
          formStatus.classList.remove('hidden', 'text-red-500');
          formStatus.classList.add('text-hoops-green-600');
        }
        
        // Reset button
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.innerHTML = 'Message Sent!';
          
          setTimeout(() => {
            submitButton.innerHTML = 'Send Message';
          }, 3000);
        }
      }, 1500);
    });
  }
}

/**
 * Newsletter Form handling
 */
function initNewsletterForm() {
  const newsletterForm = document.getElementById('newsletter-form');
  
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(event) {
      event.preventDefault();
      
      const emailInput = newsletterForm.querySelector('input[type="email"]');
      const submitButton = newsletterForm.querySelector('button[type="submit"]');
      const formStatus = document.getElementById('newsletter-status');
      
      // Show loading state
      if (submitButton) {
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="animate-spin mr-2">⏳</span> Subscribing...';
      }
      
      // Simulate form submission
      setTimeout(() => {
        // Reset form
        newsletterForm.reset();
        
        // Show success message
        if (formStatus) {
          formStatus.textContent = 'Success! You\'ve been added to our newsletter.';
          formStatus.classList.remove('hidden', 'text-red-500');
          formStatus.classList.add('text-hoops-green-600');
        }
        
        // Reset button
        if (submitButton) {
          submitButton.disabled = false;
          submitButton.innerHTML = 'Subscribed!';
          
          setTimeout(() => {
            submitButton.innerHTML = 'Subscribe';
          }, 3000);
        }
      }, 1500);
    });
  }
}

/**
 * Initialize elements based on URL parameters
 * Useful for deep linking to specific content
 */
function initializeFromURLParams() {
  const urlParams = new URLSearchParams(window.location.search);
  
  // Handle player selection in stats page
  if (urlParams.has('player')) {
    const playerId = urlParams.get('player');
    const playerRow = document.querySelector(`tr[data-player-id="${playerId}"]`);
    
    if (playerRow) {
      playerRow.classList.add('bg-hoops-green-100');
      playerRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }
  
  // Handle category filtering in news page
  if (urlParams.has('category')) {
    const category = urlParams.get('category');
    const categoryButton = document.querySelector(`[data-category="${category}"]`);
    
    if (categoryButton) {
      categoryButton.click();
    }
  }
}

/**
 * Check for dark mode preference and switch if needed
 */
function checkDarkModePreference() {
  const darkModeToggle = document.getElementById('dark-mode-toggle');
  
  if (darkModeToggle) {
    // Check for saved preference
    const darkModePref = localStorage.getItem('dark-mode');
    
    // Check system preference if no saved preference
    if (!darkModePref && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      document.documentElement.classList.add('dark-mode');
      darkModeToggle.checked = true;
    } else if (darkModePref === 'enabled') {
      document.documentElement.classList.add('dark-mode');
      darkModeToggle.checked = true;
    }
    
    // Toggle dark mode
    darkModeToggle.addEventListener('change', function() {
      if (this.checked) {
        document.documentElement.classList.add('dark-mode');
        localStorage.setItem('dark-mode', 'enabled');
      } else {
        document.documentElement.classList.remove('dark-mode');
        localStorage.setItem('dark-mode', 'disabled');
      }
    });
  }
}