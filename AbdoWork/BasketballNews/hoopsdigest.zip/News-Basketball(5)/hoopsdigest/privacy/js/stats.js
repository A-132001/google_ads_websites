/**
 * HoopsDigest.net Player Statistics Javascript
 * Provides interactive functionality for player-stats page
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all stat page functionality
    initializePositionFilters();
    initializeTableSorting();
    initializeSearch();
    initializeNewsletterForm();
    handleDarkMode();
});

/**
 * Position Filtering functionality
 */
function initializePositionFilters() {
    const filterButtons = document.querySelectorAll('[data-filter]');
    const playerRows = document.querySelectorAll('tbody tr');
    const emptyState = document.getElementById('empty-state');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Reset active state for all buttons
            filterButtons.forEach(btn => {
                btn.classList.remove('bg-hoops-green-600', 'text-white');
                btn.classList.add('bg-hoops-gray-100', 'text-hoops-gray-800', 'hover:bg-hoops-green-100');
            });
            
            // Set active state for clicked button
            button.classList.remove('bg-hoops-gray-100', 'text-hoops-gray-800', 'hover:bg-hoops-green-100');
            button.classList.add('bg-hoops-green-600', 'text-white');
            
            const position = button.getAttribute('data-filter');
            let visibleCount = 0;
            
            playerRows.forEach(row => {
                if (position === 'all' || row.getAttribute('data-position') === position) {
                    row.classList.remove('hidden');
                    visibleCount++;
                } else {
                    row.classList.add('hidden');
                }
            });
            
            // Show empty state if no players match filter
            if (visibleCount === 0) {
                emptyState.classList.remove('hidden');
            } else {
                emptyState.classList.add('hidden');
            }
        });
    });
}

/**
 * Table sorting functionality
 */
function initializeTableSorting() {
    const sortableHeaders = document.querySelectorAll('th[data-sort]');
    const tableBody = document.querySelector('tbody');
    const rows = Array.from(tableBody.querySelectorAll('tr'));
    
    let currentSortCol = 'ppg'; // Default sort column
    let sortDirection = 'desc'; // Default sort direction
    
    // Initial sort
    sortTable(currentSortCol, sortDirection);
    
    sortableHeaders.forEach(header => {
        const sortCol = header.getAttribute('data-sort');
        
        header.addEventListener('click', () => {
            // If clicking the same column, toggle direction
            if (sortCol === currentSortCol) {
                sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
                // New column, reset to descending
                currentSortCol = sortCol;
                sortDirection = 'desc';
            }
            
            // Update all headers to remove sort indicators
            sortableHeaders.forEach(h => {
                const icon = h.querySelector('svg');
                icon.classList.add('opacity-50');
                icon.classList.remove('text-hoops-green-600');
                
                // Reset icon direction
                if (h !== header) {
                    icon.style.transform = '';
                }
            });
            
            // Update clicked header with sort indicator
            const icon = header.querySelector('svg');
            icon.classList.remove('opacity-50');
            icon.classList.add('text-hoops-green-600');
            
            // Rotate icon based on sort direction
            icon.style.transform = sortDirection === 'asc' ? 'rotate(180deg)' : '';
            
            // Sort the table
            sortTable(currentSortCol, sortDirection);
        });
    });
    
    function sortTable(column, direction) {
        // Sort the rows array
        rows.sort((a, b) => {
            const aVal = parseFloat(a.querySelector(`[data-stat="${column}"]`).textContent);
            const bVal = parseFloat(b.querySelector(`[data-stat="${column}"]`).textContent);
            
            if (direction === 'asc') {
                return aVal - bVal;
            } else {
                return bVal - aVal;
            }
        });
        
        // Remove all rows from the table
        rows.forEach(row => {
            tableBody.appendChild(row);
        });
    }
}

/**
 * Search functionality
 */
function initializeSearch() {
    const searchInput = document.getElementById('player-search');
    const mobileSearchInput = document.getElementById('search-input-mobile');
    const searchForms = document.querySelectorAll('#search-form, #search-form-mobile');
    const playerRows = document.querySelectorAll('tbody tr');
    const emptyState = document.getElementById('empty-state');
    
    function performSearch(searchTerm) {
        searchTerm = searchTerm.toLowerCase().trim();
        let visibleCount = 0;
        
        playerRows.forEach(row => {
            const playerName = row.querySelector('[data-player-name]').textContent.toLowerCase();
            const team = row.querySelector('[data-team]').textContent.toLowerCase();
            
            if (playerName.includes(searchTerm) || team.includes(searchTerm)) {
                row.classList.remove('hidden');
                visibleCount++;
            } else {
                row.classList.add('hidden');
            }
        });
        
        // Show empty state if no players match search
        if (visibleCount === 0) {
            emptyState.classList.remove('hidden');
        } else {
            emptyState.classList.add('hidden');
        }
    }
    
    // Setup search listeners
    searchForms.forEach(form => {
        form.addEventListener('submit', e => {
            e.preventDefault();
            const input = form.querySelector('input[type="search"]');
            performSearch(input.value);
        });
    });
    
    // Setup search input changes
    searchInput.addEventListener('input', () => {
        if (mobileSearchInput) mobileSearchInput.value = searchInput.value;
        if (searchInput.value.length >= 2) {
            performSearch(searchInput.value);
        } else if (searchInput.value.length === 0) {
            // Reset search
            playerRows.forEach(row => row.classList.remove('hidden'));
            emptyState.classList.add('hidden');
        }
    });
    
    if (mobileSearchInput) {
        mobileSearchInput.addEventListener('input', () => {
            searchInput.value = mobileSearchInput.value;
            if (mobileSearchInput.value.length >= 2) {
                performSearch(mobileSearchInput.value);
            } else if (mobileSearchInput.value.length === 0) {
                // Reset search
                playerRows.forEach(row => row.classList.remove('hidden'));
                emptyState.classList.add('hidden');
            }
        });
    }
}

/**
 * Newsletter form submission
 */
function initializeNewsletterForm() {
    const form = document.getElementById('newsletter-form');
    const status = document.getElementById('newsletter-status');
    
    if (form) {
        form.addEventListener('submit', e => {
            e.preventDefault();
            const email = form.querySelector('input[type="email"]').value;
            
            // Simulate form submission
            status.textContent = 'Subscribing...';
            status.classList.remove('hidden', 'text-red-600', 'text-green-600');
            status.classList.add('text-hoops-gray-200');
            
            // Simulate API call
            setTimeout(() => {
                if (email && email.includes('@')) {
                    status.textContent = 'Thank you for subscribing!';
                    status.classList.remove('text-hoops-gray-200', 'text-red-600');
                    status.classList.add('text-green-600');
                    form.reset();
                } else {
                    status.textContent = 'Please enter a valid email address';
                    status.classList.remove('text-hoops-gray-200', 'text-green-600');
                    status.classList.add('text-red-600');
                }
            }, 1000);
        });
    }
}

/**
 * Dark Mode toggle handling
 */
function handleDarkMode() {
    const darkModeToggle = document.getElementById('dark-mode-toggle');
    const html = document.documentElement;
    
    // Check for saved theme preference or system preference
    const savedTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    // Set initial state
    if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
        html.classList.add('dark');
        if (darkModeToggle) darkModeToggle.checked = true;
    }
    
    if (darkModeToggle) {
        darkModeToggle.addEventListener('change', () => {
            if (darkModeToggle.checked) {
                html.classList.add('dark');
                localStorage.setItem('theme', 'dark');
            } else {
                html.classList.remove('dark');
                localStorage.setItem('theme', 'light');
            }
        });
    }
}