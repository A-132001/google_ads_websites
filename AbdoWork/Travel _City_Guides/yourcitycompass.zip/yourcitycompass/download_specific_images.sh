#!/bin/bash

# Create images directory if it doesn't exist
mkdir -p images

# Function to download image
download_image() {
    local url=$1
    local output=$2
    
    echo "Downloading $output from $url..."
    wget -O "images/$output.jpg" "$url"
    
    # Check if download was successful
    if [ $? -eq 0 ]; then
        echo "Successfully downloaded $output"
    else
        echo "Failed to download $output"
    fi
}

# Download specific images
download_image "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b" "hero-cityscape"
download_image "https://images.unsplash.com/photo-1502602898657-3e91760cbb34" "paris-guide"
download_image "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf" "tokyo-guide"
download_image "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9" "newyork-guide"

echo "All images have been downloaded"
