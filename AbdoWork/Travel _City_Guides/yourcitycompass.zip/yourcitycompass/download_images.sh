#!/bin/bash

# Create images directory if it doesn't exist
mkdir -p images

# Function to download and convert image
download_and_convert() {
    local url=$1
    local output=$2
    
    # Download image
    wget -O "temp.jpg" "$url"
    
    # Convert to WebP with optimization
    cwebp -q 80 "temp.jpg" -o "images/$output.webp"
    
    # Remove temporary file
    rm temp.jpg
}

# Download and convert images
download_and_convert "https://source.unsplash.com/random/800x600/?packing,travel" "packing-tips"
download_and_convert "https://source.unsplash.com/random/800x600/?safety,city" "safety-tips"
download_and_convert "https://source.unsplash.com/random/800x600/?budget,travel" "budget-tips"
download_and_convert "https://source.unsplash.com/random/800x600/?culture,city" "cultural-tips"
download_and_convert "https://source.unsplash.com/random/800x600/?transport,city" "transport-tips"
download_and_convert "https://source.unsplash.com/random/800x600/?hotel,accommodation" "accommodation-tips"

# Additional images for other pages
download_and_convert "https://source.unsplash.com/random/1920x1080/?cityscape" "hero-background"
download_and_convert "https://source.unsplash.com/random/800x600/?paris" "paris-guide"
download_and_convert "https://source.unsplash.com/random/800x600/?tokyo" "tokyo-guide"
download_and_convert "https://source.unsplash.com/random/800x600/?new-york" "newyork-guide"

echo "All images have been downloaded and converted to WebP format"
