#!/bin/bash

# Create a directory for WebP images if it doesn't exist
mkdir -p images/webp

# Loop through all JPG images in the images directory
for jpg_file in images/*.jpg; do
    # Skip empty files (failed downloads)
    if [ ! -s "$jpg_file" ]; then
        echo "Skipping empty file: $jpg_file"
        continue
    fi
    
    # Get the base filename without extension
    filename=$(basename -- "$jpg_file")
    filename_noext="${filename%.*}"
    
    echo "Converting $jpg_file to WebP format..."
    
    # Convert JPG to WebP with 80% quality (good balance between quality and file size)
    cwebp -q 80 "$jpg_file" -o "images/webp/$filename_noext.webp"
    
    if [ $? -eq 0 ]; then
        echo "Successfully converted $filename_noext to WebP"
    else
        echo "Failed to convert $filename_noext to WebP"
    fi
done

echo "All images have been converted to WebP format"

# Move WebP files to main images directory
mv images/webp/* images/

# Remove temporary directory
rmdir images/webp

echo "WebP images are now in the main images directory"
