#!/bin/bash

# Create images directory if it doesn't exist
mkdir -p images

# Function to download image
download_image() {
    local url=$1
    local output=$2
    
    echo "Downloading $output from $url..."
    wget -O "images/$output.jpg" "$url"
    
    # Check if download was successful
    if [ $? -eq 0 ]; then
        echo "Successfully downloaded $output"
    else
        echo "Failed to download $output"
    fi
}

# Main page images
download_image "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b" "hero-cityscape"
download_image "https://images.unsplash.com/photo-1502602898657-3e91760cbb34" "paris-guide"
download_image "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf" "tokyo-guide"
download_image "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9" "newyork-guide"

# Paris guide page images
download_image "https://images.unsplash.com/photo-1543349689-9a4d426bee8e" "eiffel-tower"
download_image "https://images.unsplash.com/photo-1544273677-c433136021d4" "louvre-museum"

# Tokyo guide page images
download_image "https://images.unsplash.com/photo-1557409518-691ebcd96038" "shibuya-crossing"
download_image "https://images.unsplash.com/photo-1583050297779-437186d01d7f" "sensoji-temple"

# New York guide page images
download_image "https://images.unsplash.com/photo-1522083165195-3424ed129620" "times-square"
download_image "https://images.unsplash.com/photo-1570168007204-dfb528c6958f" "central-park"

echo "All images have been downloaded"
